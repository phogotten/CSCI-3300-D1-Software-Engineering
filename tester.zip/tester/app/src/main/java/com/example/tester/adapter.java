package com.example.tester;

import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class adapter extends RecyclerView.Adapter<adapter.ViewHolder> {

    private ArrayList<event> adaptList;
    private listActivity main;

    public adapter(listActivity activity, ArrayList<event> initialList){
        this.main = activity;
        this.adaptList = initialList != null ? initialList : new ArrayList<>();
    }

    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.event_template, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        event item = adaptList.get(position);
        if (item != null) {
            String itemText = item.getItem();
            holder.word.setText(itemText != null ? itemText : "");
        } else {
            holder.word.setText(""); // Set to an empty string or some default text if item is null
        }

        holder.buttonDel.setOnClickListener(v -> {
            listActivity.list.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, listActivity.list.size());
        });
        holder.editButton.setOnClickListener(v -> {
            main.startEditActivity(position);
        });
        holder.checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                holder.word.setPaintFlags(holder.word.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            } else {
                holder.word.setPaintFlags(holder.word.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
            }
        });
        if (holder.checkBox.isChecked()) {
            holder.word.setPaintFlags(holder.word.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
            holder.word.setPaintFlags(holder.word.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
        }
    }

    public void setTask(ArrayList<event> myList){
        this.adaptList = myList;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return adaptList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView word;
        Button buttonDel;
        Button editButton;
        CheckBox checkBox;

        ViewHolder(View view){
            super(view);
            word = view.findViewById(R.id.textView2);
            buttonDel = view.findViewById(R.id.delButton);
            editButton = view.findViewById(R.id.editButton);
            checkBox = view.findViewById(R.id.checkBox);
        }
    }
}
