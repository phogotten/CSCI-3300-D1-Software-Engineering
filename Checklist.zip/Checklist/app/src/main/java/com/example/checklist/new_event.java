package com.example.checklist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class new_event extends AppCompatActivity {
    private EditText eventNameEditText;
    private EditText eventDescriptionEditText;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_event);

        eventNameEditText = findViewById(R.id.event_name);
        eventDescriptionEditText = findViewById(R.id.event_describe);
    }
    public void nextPage(View view){
        Intent intent = new Intent(new_event.this,MainActivity.class);

        String eventName = eventNameEditText.getText().toString();
        String eventDescription = eventDescriptionEditText.getText().toString();

        intent.putExtra("name", eventName);
        intent.putExtra("description", eventDescription);
        setResult(RESULT_OK, intent);

        MainActivity.activityResultLauncher.launch(intent);
    }
}
