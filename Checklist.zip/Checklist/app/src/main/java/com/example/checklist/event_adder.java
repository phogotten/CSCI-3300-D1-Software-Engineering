package com.example.checklist;

import android.app.Activity;
import android.media.metrics.Event;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class event_adder extends RecyclerView.Adapter<event_adder.EventViewHolder> {
    private ArrayList<Event> items;
    public static class Event{
        private String name;
        private String description;

        public Event(String name, String description) {
            this.name = name;
            this.description = description;
        }
        public String getName() {
            return name;
        }
    }

    public event_adder(ArrayList<Event> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public event_adder.EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_template, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event event = items.get(position);
        holder.eventName.setText(event.getName());
        //holder.urgencyStar.setVisibility(activity.isUrgent() ? View.VISIBLE : View.INVISIBLE);

        //holder.editButton.setOnClickListener(v -> listener.onEditClick(activity));
        //holder.deleteButton.setOnClickListener(v -> listener.onDeleteClick(activity));
    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView eventName;
        ImageView priority;
        Button editButton;
        Button deleteButton;

        public EventViewHolder(View itemView) {
            super(itemView);
            eventName = itemView.findViewById(R.id.event_name);
            //priority = itemView.findViewById(R.id.urgency_star);
            editButton = itemView.findViewById(R.id.edit);
            deleteButton = itemView.findViewById(R.id.delete);
        }
    }

    /*public interface OnEventClickListener {
        void onEditClick(Activity activity);
        void onDeleteClick(Activity activity);
    } */
}
