package com.example.checklist;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity{

    private RecyclerView recyclerView;
    private static event_adder adapter;
    private ActivityResultLauncher<Intent> activityResultLauncher;
    private static ArrayList<event_adder.Event> activities = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d("TAG", "page loaded");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.list_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new event_adder(activities);
        recyclerView.setAdapter(adapter);

        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            Intent data = result.getData();
                            if (data != null) {
                                String resultData = data.getStringExtra("result");
                                // Handle the result here
                            }
                        }
                    }
                }
        );

        updateUI();
    }

    private static void updateUI() {
        /*if (activities.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            emptyView.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            emptyView.setVisibility(View.GONE);
            adapter.notifyDataSetChanged();
        } */
        adapter.notifyDataSetChanged();
    }
    /* @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("TAG", "onActivityResult was called");
        if(resultCode == RESULT_OK){
            Log.d("TAG", "made it here");
        }
        if (requestCode == 1 && resultCode == RESULT_OK) {
            Log.d("TAG", "Accessed");
            // Get the event details from the NewEventActivity
            String name = data.getStringExtra("name");
            String description = data.getStringExtra("description");
            //int urgency = data.getIntExtra("urgency", 0);

            // Add the new event to the list
            activities.add(new event_adder.Event(name, description));

            // Update the RecyclerView to show the new event
            updateUI();
        }
    } */
    /*public ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    Log.d("TAG", "made it here finally");
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            Log.d("TAG", "made it here");
                            String name = data.getStringExtra("name");
                            String description = data.getStringExtra("description");
                            activities.add(new event_adder.Event(name, description));
                            updateUI();
                        }
                    }
                }
            }
    ); */
    public void nextPage(View view){
        Intent intent = new Intent(MainActivity.this,new_event.class);
        startActivity(intent);
    }

    /*@Override
    public void onEditClick(Activity activity) {

    }

    @Override
    public void onDeleteClick(Activity activity) {

    } */
}