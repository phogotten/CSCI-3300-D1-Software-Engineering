package com.example.checklist;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class adapter extends RecyclerView.Adapter<adapter.ViewHolder> {

    private ArrayList<event> adaptList;
    private  MainActivity main;

    public adapter(MainActivity activity){
        this.main = activity;
        this.adaptList = new ArrayList<>();
    }

    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.event_template, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        event item = adaptList.get(position);
        holder.word.setText(item.getItem());

        holder.buttonDel.setOnClickListener(v -> {
            MainActivity.list.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, MainActivity.list.size());
        });
        holder.editButton.setOnClickListener(v -> {
            main.startEditActivity(position);
        });
    }

    public void setTask(ArrayList<event> myList){
        this.adaptList = myList;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return adaptList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView word;
        Button buttonDel;
        Button editButton;

        ViewHolder(View view){
            super(view);
            word = view.findViewById(R.id.textView2);
            buttonDel = view.findViewById(R.id.delButton);
            editButton = view.findViewById(R.id.editButton);
        }
    }
}
