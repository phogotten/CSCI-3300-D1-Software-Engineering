package com.example.checklist;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class new_event extends AppCompatActivity {
    private EditText eventNameEditText;
    private boolean isEditMode = false;
    private int editPosition = -1;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_event);

        eventNameEditText = findViewById(R.id.event_name);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("position")) {
            editPosition = intent.getIntExtra("position", -1);
            isEditMode = true;

            // If we're editing, populate fields with the event data
            if (editPosition != -1) {
                event existingEvent = MainActivity.list.get(editPosition);
                eventNameEditText.setText(existingEvent.getItem());
            }
        }
    }
    public void nextPage(View view){
        String eventName = eventNameEditText.getText().toString();
        if (isEditMode && editPosition != -1) {
            // We're editing an existing event
            MainActivity.list.get(editPosition).setName(eventName);
            MainActivity.adapt.notifyItemChanged(editPosition);
            finish();
        }
        else{
            // We're creating a new event
            event item = new event();
            item.setName(eventName);
            MainActivity.list.add(item);
            MainActivity.adapt.notifyItemInserted(MainActivity.list.size() - 1);
        }
        finish();

        /*event item = new event();
        Intent intent = new Intent(new_event.this,MainActivity.class);

        item.setName(eventName);
        MainActivity.list.add(item);
        setResult(RESULT_OK, intent); */

        //startActivity(intent);
    }
}
