package com.example.checklist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class listActivity extends AppCompatActivity{

    private RecyclerView reView;
    protected static adapter adapt;
    public static ArrayList<event> list = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        reView = findViewById(R.id.list_view);
        reView.setLayoutManager(new LinearLayoutManager(this));
        adapt = new adapter(this, list);
        reView.setAdapter(adapt);
        adapt.setTask(list);
    }
    private final ActivityResultLauncher<Intent> editLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    // Update UI if necessary; list is updated directly
                    adapt.notifyDataSetChanged();
                }
            }
    );

    public void nextPage(View view){
        Intent intent = new Intent(listActivity.this,new_event.class);
        startActivity(intent);
    }
    public void startEditActivity(int position) {
        Intent editIntent = new Intent(listActivity.this, new_event.class);
        editIntent.putExtra("position", position);
        editLauncher.launch(editIntent);
    }
    public void clearList(View view) {
        new AlertDialog.Builder(this)
                .setTitle("Clear All Events")
                .setMessage("Are you sure you want to delete all events?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    list.clear();
                    adapt.notifyDataSetChanged();
                })
                .setNegativeButton("No", null)
                .show();
    }

}