package com.example.checklist;

public class event {
    private String name;

    public String getItem(){
        return name;
    }

    public void setName(String task){
        this.name = task;
    }
}
